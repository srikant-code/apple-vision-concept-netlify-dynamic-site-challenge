import { revalidateTag } from 'next/cache';

export const config = {
  path: '/revalidation'
};

// netlify/functions/revalidate.js
exports.handler = async function(event, context) {
  const tagName = 'randomWiki';
  revalidateTag(tagName);

  return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Revalidation triggered' }),
  };
}