export default function SiteLayout({children}) {
    return <main className="flex flex-col gap-8 sm:gap-16">{children}</main>;
}
