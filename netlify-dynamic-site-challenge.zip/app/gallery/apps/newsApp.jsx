import { SubmitButton } from '../common';
// if (event?.preventDefault) event.preventDefault();
// await fetch('/.netlify/functions/revalidate', { method: 'POST' });
// await fetch('/api/revalidate', { method: 'POST' });
export const metadata = {
    title: 'On-Demand Revalidation'
};

const tagName = 'randomWiki';
const randomWikiUrl = 'https://en.wikipedia.org/api/rest_v1/page/random/summary';
const maxExtractLength = 200;
const revalidateTTL = 60;

export const NewsAppContent = ({ selectedTab, setActiveApp, content, extract }) => {
    console.log({ content, extract });
    async function revalidateWiki(event) {
        // Fetch new article
        const response = await fetch(randomWikiUrl, {
            next: { revalidate: revalidateTTL, tags: [tagName] }
        });
        const newArticle = await response.json();
        console.log({ newArticle });
    }
    return (
        <div style={{ padding: 20 }}>
            <style>{`
            .pText {
                font-size: 16px;
                line-height: 1.6;
                margin-bottom: 12px;
                // color: #333;
            }
            
            li {
                font-size: 16px;
                line-height: 1.6;
                // color: #333;
            }
            
            ol, ul {
                list-style-type: decimal;
                margin-left: 20px;
            }
          `}</style>
            {selectedTab === 0 && (
                <>
                    <h2>News Articles</h2>
                    <div>
                        <div style={{}}>
                            <p className="pText">Articles</p>
                            <form className="mt-4" action={revalidateWiki}>
                                <SubmitButton text="Click to Revalidate" />
                            </form>
                            <RandomWikiArticle content={content} extract={extract}/>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};


export function RandomWikiArticle({ content, extract }) {
    console.log({ content });

    return (
        <div className="bg-white text-neutral-600 card my-6 max-w-2xl">
            <div className="card-title text-3xl px-8 pt-8">{content?.title}</div>
            <div className="card-body py-4">
                <div className="text-lg font-bold">{content?.description}</div>
                <p className="italic">{extract}</p>
                <a target="_blank" rel="noopener noreferrer" href={content?.content_urls?.desktop?.page}>
                    From Wikipedia
                </a>
            </div>
        </div>
    );
}
