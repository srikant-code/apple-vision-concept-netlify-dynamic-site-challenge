'use client';
import Image from 'next/image';
import { useState } from 'react';
import { GalleryAppContent } from './apps/galleryApp';
import { SrikantAppContent } from './apps/srikantApp';
import { Button, ReuseCSS } from './common';
import { NewsAppContent } from './apps/newsApp';

export const APP = {
    0: {
        name: 'Gallery',
        icon: `/images/applephotos.png`,
        description: (
            <>
                This app leverages Netlify&apos;s Image CDN capability. It allows you to filter images by date category.
                The images are served from cache and optimized for quick loading, demonstrating the efficiency and speed
                of Netlify&apos;s Image CDN.
            </>
        ),
        component: GalleryAppContent,
        tabs: [
            { id: 0, text: 'Years' },
            { id: 1, text: 'Months' },
            { id: 2, text: 'Days' },
            { id: 3, text: 'All Photos' }
        ]
    },
    1: {
        name: 'Folders',
        icon: `/images/applefiles.png`,
        description: (
            <>
                This app utilizes Netlify&apos;s Blobs storage to store user folder metadata and contents. In this
                prototype project, there&apos;s no authentication implemented, meaning anyone can update the folders.
                This feature showcases the flexibility and user-friendly nature of Netlify&apos;s Blobs storage.
            </>
        ),
        component: GalleryAppContent,
        tabs: [
            { id: 0, text: 'Years' },
            { id: 1, text: 'Months' },
            { id: 2, text: 'Days' },
            { id: 3, text: 'All Photos' }
        ]
    },
    2: {
        name: 'News',
        icon: `/images/applenews.png`,
        description: (
            <>
                This app uses Netlify&apos;s Cache Revalidation technique to fetch the latest news or articles from the
                web. It highlights how Netlify&apos;s Cache Revalidation can ensure users always have access to the most
                recent information.
            </>
        ),
        component: NewsAppContent,
        tabs: [{ id: 0, text: 'All News' }]
    },
    3: {
        name: 'Srikant',
        icon: `/images/srikant_profile_pic.png`,
        description: (
            <>
                This project is a hobby endeavor that I&apos;m proud of, and I hope it helps you understand the
                potential of Netlify&apos;s capabilities. Enjoy exploring!
            </>
        ),
        component: SrikantAppContent,
        tabs: [
            { id: 0, text: 'About this project' },
            { id: 1, text: 'References' }
        ]
    }
};


const tagName = 'randomWiki';
const randomWikiUrl = 'https://en.wikipedia.org/api/rest_v1/page/random/summary';
const maxExtractLength = 200;
const revalidateTTL = 60;
// This function runs on the server on each request
export async function getServerSideProps() {
    const randomWiki = await fetch(randomWikiUrl, {
        // next: { revalidate: revalidateTTL, tags: [tagName] }
    });

    const content = await randomWiki.json();
    let extract = content.extract;
    if (extract.length > maxExtractLength) {
        extract = extract.slice(0, extract.slice(0, maxExtractLength).lastIndexOf(' ')) + ' [...]';
    }

    // The returned object will be added to the props of the page component
    return { props: { content, extract } };
}


export default function Page({ props}) {
    const [activeApp, setActiveApp] = useState(1);
    console.log({ props });

    const internalStyles = {
        main: {
            ...ReuseCSS.font,
            ...ReuseCSS.center,
            height: '100vh',
            perspectiveOrigin: `center`,
            perspective: '120vw',
            overflow: 'hidden',
            ...ReuseCSS.transition
        }
    };

    const selected = (id) => id === activeApp;

    return (
        <main style={internalStyles.main}>
            <Background />
            {Object.keys(APP).map((appKey, id) => {
                return (
                    <AppTemplate
                        key={id}
                        activeApp={activeApp}
                        curAppID={id}
                        setActiveApp={setActiveApp}
                        Component={APP[appKey]?.component}
                    ></AppTemplate>
                );
            })}
            <app-drawer
                style={{
                    position: 'absolute',
                    bottom: 0,
                    display: 'flex',
                    boxShadow: `0 4px 30px rgba(0, 0, 0, 0.28)`,
                    backdropFilter: `blur(15.1px)`,
                    borderRadius: 40,
                    background: `rgba(255, 255, 255, 0.1)`,
                    padding: 8,
                    marginBottom: 40,
                    gap: 10,
                    border: `2px solid rgba(255, 255, 255, 0.34)`,
                    background: '#15151536'
                }}
            >
                {Object.keys(APP)?.map((app, id) => {
                    return (
                        <Button
                            key={id}
                            style={{ scale: selected(id) ? 1.2 : 1 }}
                            selected={selected(id)}
                            onClick={() => setActiveApp(id)}
                        >
                            {/* {APP[id]?.name} */}
                            <Image style={{}} src={APP[id]?.icon} alt={APP[id]?.name} width={40} height={40} priority />
                        </Button>
                    );
                })}
            </app-drawer>
        </main>
    );
}

const AppWrapper = ({ children, activeApp, curAppID, setActiveApp }) => {
    const isActiveApp = activeApp === curAppID;
    const diff = curAppID - activeApp;
    const curAppIsNext = diff > 0;
    const curAppIsPrev = diff < 0;
    return (
        <gallery
            style={{
                ...ReuseCSS.font,
                ...ReuseCSS.center,
                padding: 20,
                flexFlow: 'column',
                zIndex: 1,
                marginTop: -110,
                position: isActiveApp ? undefined : 'absolute',
                transform: isActiveApp ? undefined : curAppIsNext ? 'rotateY(-35deg)' : 'rotateY(35deg)',
                left: isActiveApp ? undefined : curAppIsPrev ? 150 * diff : undefined,
                right: isActiveApp ? undefined : curAppIsNext ? -150 * diff : undefined,
                scale: isActiveApp ? undefined : 0.6 - 0.1 * Math.abs(diff),
                zIndex: isActiveApp ? 100 : Math.floor(80 / Math.abs(diff)),
                ...ReuseCSS.transition
            }}
            onClick={() => {
                if (isActiveApp) return;
                else setActiveApp(curAppID);
            }}
        >
            {children}
        </gallery>
    );
};

const AppTemplate = ({ activeApp, curAppID, setActiveApp, Component }) => {
    const [selectedTab, setSelectedTab] = useState(0);
    const internalStyles = {
        image: {},
        appContainer: {
            ...ReuseCSS.font,
            margin: 20,
            borderRadius: 40,
            boxShadow: `0 4px 30px rgba(0, 0, 0, 0.28)`,
            backdropFilter: `blur(15.1px)`,
            border: `2px solid rgba(255, 255, 255, 0.34)`,
            // borderImageSource: `linear-gradient(to left, #743ad5, #d53a9d)`,
            padding: 20,
            width: '60vw',
            maxHeight: '60vh',
            overflow: 'scroll',
            resize: 'both',
            ...ReuseCSS.transition
        },
        categoriesContainer: {
            width: 'fit-content',
            borderRadius: 100,
            flexFlow: 'row',
            ...ReuseCSS.center,
            border: `2px solid rgba(255, 255, 255, 0.34)`,
            boxShadow: `0 4px 30px rgba(0, 0, 0, 0.28)`,
            backdropFilter: `blur(45.1px)`,
            padding: 8,
            gap: 10,
            marginTop: -50,
            ...ReuseCSS.transition
        },
        category: (selected) => {
            return {
                ...ReuseCSS.button(selected),
                borderRadius: 100,
                cursor: 'pointer',
                padding: `10px 24px`,
                ...ReuseCSS.transition
            };
        }
    };

    const diff = curAppID - activeApp;
    const curAppIsNext = diff > 0;
    const curAppIsPrev = diff < 0;

    return (
        <AppWrapper activeApp={activeApp} curAppID={curAppID} setActiveApp={setActiveApp}>
            <style>
                {`
                        .appContainer {
                            -ms-overflow-style: none;  /* Internet Explorer 10+ */
                            scrollbar-width: none;  /* Firefox */
                            background: rgba(255, 255, 255, 0.1);
                        }
                        .appContainer:hover {
                            background: #00000040;
                        }
                        .appContainer::-webkit-scrollbar { 
                            display: none;  /* Safari and Chrome */
                        }
                    `}
            </style>
            <h1
                style={{
                    alignSelf: curAppIsNext ? 'flex-end' : curAppIsPrev ? 'flex-start' : undefined,
                    margin: `20px 40px`,
                    display: 'flex',
                    gap: 10,
                    justifyContent: 'center'
                }}
            >
                <Image style={{}} src={APP[curAppID]?.icon} alt={APP[curAppID]?.name} width={48} height={48} priority />
                {APP[curAppID].name}
            </h1>
            <div className="appContainer" style={internalStyles.appContainer}>
                {Component ? (
                    <Component
                        selectedTab={selectedTab}
                        setSelectedTab={setSelectedTab}
                        setActiveApp={setActiveApp}
                        activeApp={activeApp}
                    />
                ) : (
                    children
                )}
            </div>
            <div>
                <div style={internalStyles.categoriesContainer}>
                    {(APP[curAppID].tabs ?? [])?.map((it, key) => {
                        return (
                            <p
                                className="category"
                                key={key}
                                style={internalStyles.category(it.id === selectedTab)}
                                onClick={(e) => {
                                    setSelectedTab(it.id);
                                }}
                            >
                                {it.text}
                            </p>
                        );
                    })}
                </div>
            </div>
        </AppWrapper>
    );
};

export const Background = () => {
    const [mousePos, setMousePos] = useState(0);
    const internalStyles = {
        main: {
            ...ReuseCSS.font,
            ...ReuseCSS.center,
            height: '100vh',
            backgroundImage: `url("/_next/image?url=%2Fimages%2Fspacejoy-9M66C_w_ToM-unsplash.jpg&w=${1920}&q=75")`,
            backgroundColor: `linear-gradient(153deg, rgba(0,0,0,1) 0%, rgba(0,0,94,1) 48%, rgba(0,84,102,1) 100%)`,
            backgroundPosition: `${50 + 10 * (mousePos.clientX / mousePos.innerWidth)}% ${
                50 + 5 * (mousePos.clientY / mousePos.innerHeight)
            }%`,
            backgroundRepeat: `no-repeat`,
            backgroundSize: `120% 120%`,
            perspectiveOrigin: `50% 40%`,
            perspective: '120vw',
            overflow: 'hidden',
            width: '100vw',
            position: 'absolute',
            transition: `all 0.2s linear`
        }
    };
    return (
        <>
            <background style={internalStyles.main}></background>
            <blur
                style={{
                    backdropFilter: `blur(2px)`,
                    width: '100vw',
                    height: '100vh',
                    position: 'fixed',
                    perspective: 600,
                    perspectiveOrigin: '100% center'
                }}
                onMouseMove={(e) => {
                    setMousePos({
                        clientX: e.clientX,
                        clientY: e.clientY,
                        innerHeight: e.view.innerHeight,
                        innerWidth: e.view.innerWidth
                    });
                }}
            ></blur>
        </>
    );
};
