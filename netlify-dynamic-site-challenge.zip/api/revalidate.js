// pages/api/revalidate.js
import { revalidateTag } from 'next/cache';

export default async function handler(req, res) {
    const tagName = 'randomWiki';
    revalidateTag(tagName);
    res.status(200).json({ message: 'Revalidation triggered' });
}
